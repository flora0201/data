package com.company;

public class College{
    int id;
    String name;
    public void studDetails(int id,String name){
        System.out.println("Get details");
    }
}
