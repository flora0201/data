package com.company;

import java.sql.*;
import java.util.Scanner;

public class Main {
    static String url="jdbc:mysql://localhost:3306/demo";
    static String userName="root";
    static String pass="root";
    static Connection con=null;
    static Statement stm=null;

    public static void main(String args[]) throws Exception{
        dataConnection();
        input();
    }
    public static void input() throws Exception{
        Scanner sc = new Scanner(System.in);
        String sql;
        String name;
        int id;
        {
        public void studDetails(){
            System.out.println("enter name");
            name=sc.nextLine();
            System.out.println("enter id");
            id=sc.nextInt();
            stm= con.createStatement();
            sql="INSERT INTO student VALUES(?,?)";
            PreparedStatement stmt=con.prepareStatement(sql);
            stmt.setString(1,name);
            stmt.setInt(2,id);
            System.out.println(sql);
            stmt.executeUpdate();
        }
    }


    public static void dataConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, userName, pass);
            if (con != null) {
                System.out.println("jdbc connected");
            }
        } catch (Exception e) {
            System.out.println(e);

        }

    }


