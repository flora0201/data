package com.company;

public class Student extends College {
    String lastname;
}
